# IO.Swagger.Api.DefaultApi

All URIs are relative to *https://virtserver.swaggerhub.com/Javierdeleon02/ServidorHTTP/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddKeyAddsharedSecret**](DefaultApi.md#addkeyaddsharedsecret) | **PUT** /credential | 
[**AddmsgAddtags**](DefaultApi.md#addmsgaddtags) | **POST** /message | 
[**MessageidGet**](DefaultApi.md#messageidget) | **GET** /message/&lt;id&gt; | 
[**MessagetagGet**](DefaultApi.md#messagetagget) | **GET** /message/&lt;tag&gt; | 

<a name="addkeyaddsharedsecret"></a>
# **AddKeyAddsharedSecret**
> void AddKeyAddsharedSecret (List<Keyingresado> key, string sharedSecret)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AddKeyAddsharedSecretExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var key = new List<Keyingresado>(); // List<Keyingresado> | 
            var sharedSecret = sharedSecret_example;  // string | 

            try
            {
                apiInstance.AddKeyAddsharedSecret(key, sharedSecret);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.AddKeyAddsharedSecret: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **key** | [**List&lt;Keyingresado&gt;**](Keyingresado.md)|  | 
 **sharedSecret** | **string**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="addmsgaddtags"></a>
# **AddmsgAddtags**
> Identificador AddmsgAddtags (List<Tagingresado> msg, List<Tagingresado> tags)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AddmsgAddtagsExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var msg = new List<Tagingresado>(); // List<Tagingresado> | 
            var tags = new List<Tagingresado>(); // List<Tagingresado> | 

            try
            {
                Identificador result = apiInstance.AddmsgAddtags(msg, tags);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.AddmsgAddtags: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **msg** | [**List&lt;Tagingresado&gt;**](Tagingresado.md)|  | 
 **tags** | [**List&lt;Tagingresado&gt;**](Tagingresado.md)|  | 

### Return type

[**Identificador**](Identificador.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="messageidget"></a>
# **MessageidGet**
> Msgingresado MessageidGet ()



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MessageidGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();

            try
            {
                Msgingresado result = apiInstance.MessageidGet();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.MessageidGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Msgingresado**](Msgingresado.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="messagetagget"></a>
# **MessagetagGet**
> Tagingresado MessagetagGet ()



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MessagetagGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();

            try
            {
                Tagingresado result = apiInstance.MessagetagGet();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.MessagetagGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Tagingresado**](Tagingresado.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
